import React, { useState, useRef, useEffect } from 'react';
import {
  FileText, User, Heart, Home, TrendingUp, Target, ChevronRight, Calendar, DollarSign, MapPin, Briefcase, Sparkles, Coffee, Zap, Mic, MicOff, Volume2, VolumeX, ArrowRight, ArrowLeft, MessageCircle,
  Car, Plane, Baby, GraduationCap, Activity, Utensils, ShoppingBag, AlertCircle, Rocket, Wine, Palmtree, TrendingDown, Calculator, PiggyBank, Lock, Unlock, Star, Info, CheckCircle, XCircle, BarChart3, Lightbulb, Clock, Shield, PartyPopper, Flame, Crown, Gem, Menu, X, Edit, RefreshCw, Send
} from 'lucide-react';
import voiceService from './services/voiceService';

const FinancialTherapyPlatform = () => {
  // Main app state
  const [currentPage, setCurrentPage] = useState('landing');
  const [userJourney, setUserJourney] = useState({
    hasCompletedConversation: false,
    hasSetupProfile: false,
    hasCompletedPlanning: false,
    currentStep: 'landing' // landing, conversation, profile, planning, tools, optimization
  });

  // Voice conversation state (from simplified version)
  const [chatMessages, setChatMessages] = useState([]);
  const [chatInput, setChatInput] = useState('');
  const [currentConversationStep, setCurrentConversationStep] = useState('intro');
  const [conversationResponses, setConversationResponses] = useState({});
  const [showConversationResults, setShowConversationResults] = useState(false);
  
  // Life Values Report state (from previous comprehensive version)
  const [personalizedInsights, setPersonalizedInsights] = useState([]);
  const [showLifeValuesReport, setShowLifeValuesReport] = useState(false);
  
  // Voice functionality state
  const [isRecording, setIsRecording] = useState(false);
  const [isAISpeaking, setIsAISpeaking] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [speechRecognition, setSpeechRecognition] = useState(null);
  const [speechSynthesis, setSpeechSynthesis] = useState(null);
  const [voiceProvider, setVoiceProvider] = useState('browser'); // 'browser', 'openai', 'elevenlabs'
  const [showApiKeyInput, setShowApiKeyInput] = useState(false);
  const [apiKey, setApiKey] = useState('');
  const [selectedVoice, setSelectedVoice] = useState('nova'); // OpenAI voice selection
  const recognitionRef = useRef(null);
  const synthRef = useRef(null);
  const currentAudioRef = useRef(null);

  // Financial Health Score State
  const [financialHealthScore, setFinancialHealthScore] = useState(0);
  const [showHealthScore, setShowHealthScore] = useState(false);
  
  // What-if Scenarios State
  const [showWhatIf, setShowWhatIf] = useState(false);
  const [whatIfScenario, setWhatIfScenario] = useState({
    incomeChange: 0,
    expenseChange: 0,
    savingsRateChange: 0
  });
  
  // Lifestyle Survey State (kept for alternative flow)
  const [surveyStep, setSurveyStep] = useState(0);
  const [surveyQuestionIndex, setSurveyQuestionIndex] = useState(0);
  const [surveyResponses, setSurveyResponses] = useState({});
  const [showSurveyReport, setShowSurveyReport] = useState(false);
  const [showChat, setShowChat] = useState(false);
  
  // Wellness Rings State
  const [wellnessRings, setWellnessRings] = useState({
    safety: { progress: 45, goal: 100, color: 'from-teal-400 to-teal-600' },
    freedom: { progress: 25, goal: 100, color: 'from-white to-gray-300' },
    fulfillment: { progress: 70, goal: 100, color: 'from-purple-400 to-purple-600' }
  });
  const [showRingsDetail, setShowRingsDetail] = useState(false);
  const [dailyReflection, setDailyReflection] = useState('');
  const [showReflectionPrompt, setShowReflectionPrompt] = useState(false);

  // Financial Planning State (from comprehensive version)
  const [currentPlanningStep, setCurrentPlanningStep] = useState(1);
  const [currentPhase, setCurrentPhase] = useState('twenties');
  const [investmentStrategy, setInvestmentStrategy] = useState('balanced');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Enhanced Financial Profile with Life Values integration
  const [financialProfile, setFinancialProfile] = useState({
    age: 25,
    location: 'medium',
    familyStatus: 'single',
    dependents: 0,
    currentIncome: 60000,
    partnerIncome: 0,
    currentSavings: 10000,
    emergencyFund: 5000,
    checking: 3000,
    savings: 7000,
    investments: 15000,
    retirement401k: 8000,
    rothIRA: 5000,
    debt: { 
      student: 25000, 
      credit: 3000, 
      car: 12000, 
      mortgage: 0,
      other: 0 
    },
    monthlyExpenses: 4500,
    rentMortgage: 1800,
    riskTolerance: 'medium',
    timeCommitment: 'medium',
    careerStage: 'early',
    retirementGoal: 65,
    investmentExperience: 'beginner',
    hasRetirement401k: true,
    hasRothIRA: false,
    hasStocks: false,
    financialGoals: {
      buyHome: true,
      travel: true,
      earlyRetirement: false,
      startBusiness: false,
      payOffDebt: true
    },
    // Life Values from conversation
    lifeValues: {
      coreMotivations: [],
      personalityType: '',
      financialArchetype: '',
      hiddenFears: [],
      behavioralPatterns: []
    }
  });

  // Income and lifestyle planning
  const [incomeByDecade, setIncomeByDecade] = useState({
    twenties: { you: 59000, partner: 52000 },
    thirties: { you: 71000, partner: 65000 },
    forties: { you: 85000, partner: 78000 },
    fifties: { you: 95000, partner: 88000 },
    sixties: { you: 50000, partner: 45000 }
  });
  
  const [lifestyleChoices, setLifestyleChoices] = useState({
    twenties: { housing: 'medium', transportation: 'medium', food: 'medium', entertainment: 'medium', location: 'medium' },
    thirties: { housing: 'medium', transportation: 'medium', food: 'medium', childcare: 'medium', healthcare: 'medium', location: 'medium' },
    forties: { housing: 'high', transportation: 'medium', food: 'medium', education: 'medium', healthcare: 'medium', location: 'medium' },
    fifties: { housing: 'high', transportation: 'medium', food: 'medium', college: 'high', healthcare: 'high', location: 'medium' },
    sixties: { housing: 'medium', transportation: 'low', food: 'medium', healthcare: 'high', travel: 'medium', location: 'medium' }
  });
  
  const [savingsRateByDecade, setSavingsRateByDecade] = useState({
    twenties: 20, thirties: 15, forties: 25, fifties: 30, sixties: 10
  });

  // Initialize voice conversation when it starts
  useEffect(() => {
    if (currentPage === 'conversation' && chatMessages.length === 0) {
      setChatMessages([
        {
          type: 'therapist',
          message: "Hey! I'm here to chat about your money stuff - no judgment, just real talk.",
          timestamp: new Date()
        },
        {
          type: 'therapist', 
          message: "Let's start easy - what's something you bought recently that made you smile?",
          timestamp: new Date()
        }
      ]);
    }
  }, [currentPage]);

  // Initialize voice functionality
  useEffect(() => {
    const initializeVoice = async () => {
      // Initialize voice service - prioritize OpenAI if available
      voiceService.initialize({
        openaiApiKey: apiKey || null
      });

      // Check if browser supports speech recognition
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      
      if (SpeechRecognition) {
        try {
          // Request microphone permission first
          await navigator.mediaDevices.getUserMedia({ audio: true });
          
          const recognition = new SpeechRecognition();
          recognition.continuous = false;
          recognition.interimResults = true;
          recognition.lang = 'en-US';
          recognition.maxAlternatives = 1;
          
          recognition.onstart = () => {
            console.log('Voice recognition started');
            setIsRecording(true);
          };
          
          recognition.onresult = (event) => {
            console.log('Voice recognition result received');
            let finalTranscript = '';
            let interimTranscript = '';
            
            for (let i = event.resultIndex; i < event.results.length; i++) {
              const transcript = event.results[i][0].transcript;
              if (event.results[i].isFinal) {
                finalTranscript += transcript;
              } else {
                interimTranscript += transcript;
              }
            }
            
            if (finalTranscript) {
              setChatInput(finalTranscript.trim());
              setIsRecording(false);
            } else if (interimTranscript) {
              setChatInput(interimTranscript.trim());
            }
          };
          
          recognition.onerror = (event) => {
            console.error('Speech recognition error:', event.error);
            setIsRecording(false);
            
            // Show user-friendly error messages
            if (event.error === 'not-allowed') {
              alert('Microphone access denied. Please allow microphone access and try again.');
            } else if (event.error === 'no-speech') {
              console.log('No speech detected');
            } else {
              console.log('Speech recognition error:', event.error);
            }
          };
          
          recognition.onend = () => {
            console.log('Voice recognition ended');
            setIsRecording(false);
          };
          
          recognitionRef.current = recognition;
          setSpeechRecognition(recognition);
          
        } catch (error) {
          console.error('Error accessing microphone:', error);
          setSpeechRecognition(null);
        }
      } else {
        console.log('Speech recognition not supported');
        setSpeechRecognition(null);
      }

      // Initialize browser speech synthesis (fallback)
      if (window.speechSynthesis) {
        synthRef.current = window.speechSynthesis;
        setSpeechSynthesis(window.speechSynthesis);
        
        // Load voices
        if (speechSynthesis.getVoices().length === 0) {
          speechSynthesis.addEventListener('voiceschanged', () => {
            console.log('Voices loaded');
          });
        }
      }
    };

    initializeVoice();
  }, [apiKey, voiceProvider]);

  // Auto-speak new therapist messages
  useEffect(() => {
    if (voiceEnabled && chatMessages.length > 0) {
      const lastMessage = chatMessages[chatMessages.length - 1];
      if (lastMessage.type === 'therapist' && speechSynthesis) {
        speakMessage(lastMessage.message);
      }
    }
  }, [chatMessages, voiceEnabled, speechSynthesis]);

  const startRecording = async () => {
    if (!recognitionRef.current) {
      alert('Speech recognition not available. Please try typing your response.');
      return;
    }

    try {
      // Make sure we have microphone permission
      await navigator.mediaDevices.getUserMedia({ audio: true });
      
      if (!isRecording) {
        console.log('Starting voice recognition...');
        setChatInput(''); // Clear input before starting
        recognitionRef.current.start();
      }
    } catch (error) {
      console.error('Error starting recording:', error);
      if (error.name === 'NotAllowedError') {
        alert('Microphone access denied. Please allow microphone access in your browser settings and try again.');
      } else {
        alert('Unable to access microphone. Please check your browser settings.');
      }
      setIsRecording(false);
    }
  };

  const stopRecording = () => {
    if (recognitionRef.current && isRecording) {
      console.log('Stopping voice recognition...');
      recognitionRef.current.stop();
    }
  };

  const speakMessage = async (text) => {
    if (!voiceEnabled) return;

    console.log(`🗣️ Speaking message with provider: ${voiceProvider}, voice: ${selectedVoice}, API key available: ${!!apiKey}`);

    // Stop any current audio
    if (currentAudioRef.current) {
      currentAudioRef.current.pause();
      currentAudioRef.current = null;
    }
    voiceService.stop();

    try {
      const audio = await voiceService.speak(
        text,
        () => {
          console.log('🎤 Voice started playing');
          setIsAISpeaking(true);
        },
        () => {
          console.log('✅ Voice finished playing');
          setIsAISpeaking(false);
        },
        (error) => {
          console.error('❌ Voice synthesis error:', error);
          setIsAISpeaking(false);
        }
      );
      
      // Store reference to current audio for stopping if needed
      if (audio && audio.pause) {
        currentAudioRef.current = audio;
      }
    } catch (error) {
      console.error('❌ Failed to speak message:', error);
      setIsAISpeaking(false);
    }
  };

  const toggleVoice = () => {
    setVoiceEnabled(!voiceEnabled);
    if (isAISpeaking) {
      if (currentAudioRef.current) {
        currentAudioRef.current.pause();
        currentAudioRef.current = null;
      }
      voiceService.stop();
      setIsAISpeaking(false);
    }
  };

  // Configure OpenAI API key
  const configureOpenAI = () => {
    const key = prompt('Enter your OpenAI API key:');
    if (key && key.startsWith('sk-')) {
      setApiKey(key);
      setVoiceProvider('openai');
      localStorage.setItem('openai_api_key', key);
      voiceService.switchProvider('openai', { openaiApiKey: key });
      console.log('✅ OpenAI TTS configured');
    } else {
      alert('Invalid OpenAI API key. It should start with "sk-"');
    }
  };

  // Switch voice provider
  const switchVoiceProvider = (provider) => {
    setVoiceProvider(provider);
    if (provider === 'openai' && !apiKey) {
      configureOpenAI();
    } else if (provider === 'browser') {
      voiceService.switchProvider('browser');
    }
  };

  // Load API key from localStorage on component mount
  useEffect(() => {
    const savedApiKey = localStorage.getItem('openai_api_key');
    if (savedApiKey) {
      setApiKey(savedApiKey);
      setVoiceProvider('openai');
      console.log('🔑 OpenAI API key loaded from storage');
    }
  }, []);

  // Update voice provider when API key changes
  useEffect(() => {
    if (apiKey && apiKey.startsWith('sk-')) {
      setVoiceProvider('openai');
      voiceService.switchProvider('openai', { openaiApiKey: apiKey });
      voiceService.updateConfig('openai', { voice: selectedVoice });
      console.log(`🚀 Switched to OpenAI TTS with HD model using ${selectedVoice} voice`);
    }
  }, [apiKey, selectedVoice]);

  // Update voice selection
  const changeVoice = (newVoice) => {
    setSelectedVoice(newVoice);
    localStorage.setItem('openai_voice', newVoice);
    if (voiceProvider === 'openai') {
      voiceService.updateConfig('openai', { voice: newVoice });
      console.log(`🎤 Changed OpenAI voice to: ${newVoice}`);
    }
  };

  // Load voice preference on mount
  useEffect(() => {
    const savedVoice = localStorage.getItem('openai_voice');
    if (savedVoice) {
      setSelectedVoice(savedVoice);
    }
  }, []);

  // Therapy conversation flow
  const therapyFlow = [
    {
      id: 'intro',
      question: "What's something you bought recently that made you smile?",
      followUp: "That's cool! Now here's a different question - what's something you spent money on and immediately regretted it?"
    },
    {
      id: 'guilt_spending',
      question: "What's something you spent money on and immediately regretted it?",
      followUp: "Ugh, been there! Let's talk about fun stuff - if you had $200 to spend on yourself this weekend, what would you do?"
    },
    {
      id: 'ideal_weekend',
      question: "If you had $200 to spend on yourself this weekend, what would you do?",
      followUp: "Sounds fun! Here's a weird question - do you know roughly how much you spend in a week? Just ballpark it."
    },
    {
      id: 'weekly_spending',
      question: "Do you know roughly how much you spend in a week?",
      followUp: "No judgment on the number! Now think about this - what's the biggest money worry on your mind lately?"
    },
    {
      id: 'money_worry',
      question: "What's the biggest money worry on your mind lately?",
      followUp: "I get that. Last question - is there something you really want but it feels too expensive right now?"
    },
    {
      id: 'big_want',
      question: "Is there something you really want but feels too expensive right now?",
      followUp: "Alright, here's the interesting part - I think your spending patterns might actually help you get that. Let me show you something..."
    }
  ];

  const sendMessage = () => {
    if (!chatInput.trim()) return;

    const newUserMessage = {
      type: 'user',
      message: chatInput,
      timestamp: new Date()
    };

    setChatMessages(prev => [...prev, newUserMessage]);
    
    // Store user response
    const currentStepData = therapyFlow.find(step => step.id === currentConversationStep);
    if (currentStepData) {
      setConversationResponses(prev => ({
        ...prev,
        [currentConversationStep]: chatInput
      }));
    }

    // Add therapist response after delay
    setTimeout(() => {
      const stepIndex = therapyFlow.findIndex(step => step.id === currentConversationStep);
      
      if (stepIndex !== -1 && stepIndex < therapyFlow.length - 1) {
        // Continue conversation
        const currentStepData = therapyFlow[stepIndex];
        const therapistResponse = {
          type: 'therapist',
          message: currentStepData.followUp,
          timestamp: new Date()
        };
        
        setChatMessages(prev => [...prev, therapistResponse]);
        setCurrentConversationStep(therapyFlow[stepIndex + 1].id);
      } else {
        // End conversation and show results
        const finalResponse = {
          type: 'therapist',
          message: "Alright, this is getting interesting! Let me crunch these numbers and show you what I found...",
          timestamp: new Date()
        };
        
        setChatMessages(prev => [...prev, finalResponse]);
        
        setTimeout(() => {
          generateLifestyleAnalysis();
          setShowConversationResults(true);
          setUserJourney(prev => ({ 
            ...prev, 
            hasCompletedConversation: true, 
            currentStep: 'profile' 
          }));
        }, 2000);
      }
    }, 1500);

    setChatInput('');
  };

  // Life Values Report Analysis Functions (integrated from previous version)
  const analyzePersonalityMatrix = (conversationText) => {
    const text = conversationText.toLowerCase();
    return {
      riskTolerance: (text.includes('save') && text.includes('secure')) || text.includes('safe') ? 'conservative' : 'aggressive',
      timeOrientation: text.includes('now') || text.includes('today') || text.includes('experience') ? 'present' : 'future',
      socialOrientation: text.includes('family') || text.includes('friends') || text.includes('relationship') ? 'social' : 'individual'
    };
  };

  const getFinancialArchetype = (conversationText) => {
    const text = conversationText.toLowerCase();
    
    if ((text.includes('save') || text.includes('independence')) && (text.includes('freedom') || text.includes('security'))) {
      return {
        category: "🎯 Your Financial Archetype",
        title: "💎 The Wealth Builder",
        description: "You're not just saving money—you're architecting financial freedom. You see money as a tool for ultimate independence, and you're willing to sacrifice short-term pleasures for long-term power.",
        deepInsight: "Your drive for financial control could be masking a fear of being dependent on others or situations beyond your control.",
        actionItems: [
          "Set up automatic investing so wealth building happens without constant decisions",
          "Create a 'joy budget' - allocate money for present happiness without guilt",
          "Track your 'enough number' - what amount would make you feel truly secure?"
        ]
      };
    }
    
    if (text.includes('experience') || text.includes('travel') || text.includes('adventure') || text.includes('memories')) {
      return {
        category: "🎯 Your Financial Archetype", 
        title: "✨ The Experience Collector",
        description: "Money, to you, is energy that creates memories and connections. You understand that life is happening now, not someday. You're investing in your soul, not just your portfolio.",
        deepInsight: "Your 'spending' on experiences is actually sophisticated emotional investing. But you might avoid traditional planning because it feels restrictive.",
        actionItems: [
          "Create an 'Adventure Fund' that makes saving feel exciting",
          "Use travel rewards credit cards to turn spending into future experiences",
          "Set up automatic investing in index funds - 'set it and forget it' while you live"
        ]
      };
    }
    
    if (text.includes('family') || text.includes('others') || text.includes('help')) {
      return {
        category: "🎯 Your Financial Archetype",
        title: "💕 The Family Architect", 
        description: "You don't just think about money—you think about legacy, security for people you love, and creating a foundation for others to thrive.",
        deepInsight: "You might be carrying the emotional weight of everyone's financial security, leading to anxiety about 'having enough'.",
        actionItems: [
          "Set up separate savings buckets for each family goal",
          "Create a 'self-care budget' - you can't pour from an empty cup",
          "Have honest conversations with family about financial priorities"
        ]
      };
    }
    
    // Default archetype
    return {
      category: "🎯 Your Financial Archetype",
      title: "🌟 The Balanced Seeker",
      description: "You're still discovering your relationship with money, and that's actually a strength. You have the flexibility to create a financial life that truly fits you.",
      deepInsight: "Your uncertainty about money might actually be wisdom—you're sensing that generic advice doesn't fit everyone.",
      actionItems: [
        "Start with basic automation - emergency fund and retirement savings",
        "Experiment with small financial decisions to learn your preferences",
        "Set one specific financial goal to build confidence"
      ]
    };
  };

  const getHiddenMotivations = (conversationText) => {
    const text = conversationText.toLowerCase();
    const fears = [];
    const desires = [];
    
    if (text.includes('worry') || text.includes('stress') || text.includes('behind')) {
      fears.push("Financial vulnerability and dependence");
      desires.push("Complete control over life circumstances");
    }
    if (text.includes('work') && (text.includes('tired') || text.includes('balance'))) {
      fears.push("Losing yourself in pursuit of success");
      desires.push("Authentic self-expression and freedom");
    }
    
    return {
      category: "🔍 Hidden Psychology",
      title: "💭 What Really Drives Your Money Decisions",
      description: "Your financial behavior isn't just about money—it's about deeper emotional needs.",
      deepInsight: `You're likely motivated by: ${desires.join(', ') || 'personal growth and security'}. But underneath, you might be avoiding: ${fears.join(', ') || 'loss of control and independence'}.`,
      actionItems: [
        "Before major financial decisions, ask: 'What am I really trying to achieve?'",
        "Notice when you feel anxious about money and explore the deeper fear",
        "Create goals that align with your core values, not external expectations"
      ]
    };
  };

  const getBehavioralPatterns = (conversationText) => {
    const text = conversationText.toLowerCase();
    let pattern = "Adaptive Planner";
    let description = "You take a thoughtful, balanced approach to money decisions.";
    
    if (text.includes('plan') || text.includes('strategy') || text.includes('goal')) {
      pattern = "Strategic Optimizer";
      description = "You approach money like a chess game—always thinking several moves ahead.";
    } else if (text.includes('experience') || text.includes('friends') || text.includes('social')) {
      pattern = "Social Investor";
      description = "You spend money to create connections and memories. Your ROI is measured in joy and relationships.";
    } else if (text.includes('value') || text.includes('important') || text.includes('matter')) {
      pattern = "Values-Driven Spender";
      description = "Your money decisions are extensions of your values. You're willing to pay more for things that align with your beliefs.";
    }
    
    return {
      category: "⚡ Behavioral Patterns",
      title: `🧠 You're a ${pattern}`,
      description: description,
      deepInsight: `This pattern serves you well but might create blind spots in other financial areas.`,
      actionItems: [
        "Identify one financial area where your pattern might not serve you",
        "Seek advice from people with complementary financial patterns",
        "Set up automatic systems for areas where you're not naturally strong"
      ]
    };
  };

  // Helper functions to extract values from conversation
  const extractMotivations = (text) => {
    const motivations = [];
    if (text.includes('freedom') || text.includes('independence')) motivations.push('Financial Freedom');
    if (text.includes('family') || text.includes('help')) motivations.push('Family Security');
    if (text.includes('experience') || text.includes('travel')) motivations.push('Life Experiences');
    if (text.includes('save') || text.includes('future')) motivations.push('Future Security');
    return motivations.length > 0 ? motivations : ['Personal Growth'];
  };

  const extractPersonalityType = (text) => {
    if (text.includes('plan') && text.includes('goal')) return 'Strategic Planner';
    if (text.includes('experience') && text.includes('now')) return 'Present-Focused';
    if (text.includes('family') || text.includes('others')) return 'Relationship-Centered';
    return 'Balanced Explorer';
  };

  const extractHiddenFears = (text) => {
    const fears = [];
    if (text.includes('worry') || text.includes('stress')) fears.push('Financial insecurity');
    if (text.includes('behind') || text.includes('compare')) fears.push('Falling behind peers');
    if (text.includes('work') && text.includes('balance')) fears.push('Losing life balance');
    return fears.length > 0 ? fears : ['Uncertainty about the future'];
  };

  const extractBehavioralPatterns = (text) => {
    const patterns = [];
    if (text.includes('plan') || text.includes('strategy')) patterns.push('Strategic thinking');
    if (text.includes('feel') || text.includes('emotion')) patterns.push('Emotion-driven decisions');
    if (text.includes('research') || text.includes('learn')) patterns.push('Information gathering');
    return patterns.length > 0 ? patterns : ['Thoughtful decision-making'];
  };

  const getPersonalizedInsights = (conversationText) => {
    const insights = [];
    
    // Core archetype analysis
    insights.push(getFinancialArchetype(conversationText));
    
    // Hidden motivations
    insights.push(getHiddenMotivations(conversationText));
    
    // Behavioral patterns
    insights.push(getBehavioralPatterns(conversationText));
    
    return insights.filter(insight => insight !== null);
  };

  const generateLifestyleAnalysis = () => {
    // Extract insights from user responses
    const analysis = {
      joySpending: conversationResponses.intro || "",
      guiltSpending: conversationResponses.guilt_spending || "",
      idealDay: conversationResponses.ideal_day || "",
      happinessBudget: parseInt(conversationResponses.happiness_budget) || 0,
      wasteBudget: parseInt(conversationResponses.waste_spending) || 0,
      bigGoal: conversationResponses.big_goal || ""
    };

    // Generate Life Values Report insights from conversation
    const conversationValues = Object.values(conversationResponses).filter(Boolean).join(' ').toLowerCase();
    const lifeValuesInsights = getPersonalizedInsights(conversationValues);
    setPersonalizedInsights(lifeValuesInsights);

    // Update financial profile based on conversation and archetype analysis
    setFinancialProfile(prev => ({
      ...prev,
      lifeValues: {
        coreMotivations: extractMotivations(conversationValues),
        personalityType: extractPersonalityType(conversationValues),
        financialArchetype: lifeValuesInsights.find(i => i.category.includes('Archetype'))?.title || 'The Balanced Seeker',
        hiddenFears: extractHiddenFears(conversationValues),
        behavioralPatterns: extractBehavioralPatterns(conversationValues)
      }
    }));

    // Update wellness rings based on conversation insights
    setWellnessRings(prev => ({
      safety: { ...prev.safety, progress: analysis.wasteBudget > 500 ? 35 : 60 },
      freedom: { ...prev.freedom, progress: analysis.happinessBudget > 200 ? 50 : 30 },
      fulfillment: { ...prev.fulfillment, progress: analysis.joySpending ? 75 : 45 }
    }));
  };

  const calculateFinancialImpact = () => {
    const responses = conversationResponses;
    const monthlyWaste = parseInt(responses.waste_spending) || 0;
    const yearlyWaste = monthlyWaste * 12;
    const fiveYearWaste = yearlyWaste * 5;
    const tenYearInvested = yearlyWaste * 10 * 1.07; // 7% return
    
    return {
      monthlyWaste,
      yearlyWaste,
      fiveYearWaste,
      tenYearInvested: Math.round(tenYearInvested)
    };
  };

  // Investment strategies
  const strategies = {
    conservative: {
      name: '🛡️ Play It Safe',
      description: 'Low risk, slow growth',
      allocation: { stocks: 40, bonds: 50, cash: 10 },
      expectedReturn: 0.045,
      riskLevel: '😌 Chill'
    },
    balanced: {
      name: '⚖️ Balanced Boss',
      description: 'Good mix of growth and safety',
      allocation: { stocks: 65, bonds: 25, cash: 10 },
      expectedReturn: 0.058,
      riskLevel: '🔥 Steady'
    },
    aggressive: {
      name: '🚀 YOLO Growth',
      description: 'High risk, high reward',
      allocation: { stocks: 85, bonds: 10, cash: 5 },
      expectedReturn: 0.065,
      riskLevel: '💎 Beast Mode'
    }
  };

  // Phase definitions with detailed content
  const phases = {
    twenties: { 
      title: "🎉 Your Wild 20s", 
      icon: Coffee, 
      ageRange: "22-29",
      description: "Starting career, building habits, having fun! 🍕",
      vibe: "Building your foundation while living your best life",
      priorities: ["Career building", "Emergency fund", "Debt payoff", "Experiences"],
      expenses: ["Rent/Housing", "Student loans", "Food/Social", "Transportation"],
      investments: ["401k match", "Index funds", "Roth IRA"],
      goals: ["$10k emergency fund", "Pay off high-interest debt", "Invest 15% of income"]
    },
    thirties: { 
      title: "👨‍👩‍👧 Family Time 30s", 
      icon: Baby, 
      ageRange: "30-39",
      description: "Career growth, maybe kids, getting serious 💪",
      vibe: "Balancing responsibility with dreams",
      priorities: ["Family planning", "Home buying", "Career advancement", "Wealth building"],
      expenses: ["Mortgage/Rent", "Childcare", "Healthcare", "Family needs"],
      investments: ["529 plans", "Real estate", "Diversified portfolio", "Life insurance"],
      goals: ["Buy a home", "Save for kids' college", "Increase income 50%"]
    },
    forties: { 
      title: "💰 Peak Earning 40s", 
      icon: Target, 
      ageRange: "40-49",
      description: "Maximum income, peak lifestyle, wealth building 📈",
      vibe: "Living your best life while building for the future",
      priorities: ["Peak earning", "College savings", "Retirement acceleration", "Lifestyle optimization"],
      expenses: ["Peak lifestyle", "Kids' activities", "Healthcare", "Travel"],
      investments: ["Max retirement accounts", "Taxable investments", "Real estate", "Education funds"],
      goals: ["2x annual income saved", "College funds fully funded", "Consider early retirement"]
    },
    fifties: { 
      title: "🎯 Final Sprint 50s", 
      icon: Target, 
      ageRange: "50-59",
      description: "College costs, serious retirement prep 🏃‍♂️",
      vibe: "Last chance to maximize your wealth",
      priorities: ["Retirement preparation", "College payments", "Healthcare planning", "Estate planning"],
      expenses: ["College tuition", "Healthcare premiums", "Aging parents", "Travel"],
      investments: ["Catch-up contributions", "Conservative shift", "Long-term care insurance", "Estate planning"],
      goals: ["10x annual income saved", "Debt-free except mortgage", "Healthcare covered"]
    },
    sixties: { 
      title: "🌴 Freedom Years 60s+", 
      icon: Palmtree, 
      ageRange: "60+",
      description: "Retirement, travel, pure enjoyment! ✈️",
      vibe: "Reaping the rewards of your hard work",
      priorities: ["Retirement income", "Healthcare", "Legacy planning", "Enjoyment"],
      expenses: ["Healthcare", "Travel", "Hobbies", "Family gifts"],
      investments: ["Income generation", "Conservative allocation", "Healthcare funds", "Legacy planning"],
      goals: ["Sustainable withdrawal rate", "Healthcare covered", "Legacy planned"]
    }
  };

  // Calculate savings rate
  const savingsRate = Object.values(savingsRateByDecade).reduce((sum, rate) => sum + rate, 0) / 5;

  // Calculate retirement projection
  const calculateRetirement = () => {
    const strategy = strategies[investmentStrategy];
    let netWorth = 0;
    let age = 25;
    
    while (age < 85) {
      const phase = age < 30 ? 'twenties' :
                   age < 40 ? 'thirties' :
                   age < 50 ? 'forties' :
                   age < 60 ? 'fifties' : 'sixties';
      
      const income = incomeByDecade[phase];
      const totalIncome = income.you + income.partner;
      const savings = Math.max(0, totalIncome * (savingsRateByDecade[phase] / 100));
      
      netWorth = netWorth * (1 + strategy.expectedReturn) + savings;
      
      if (netWorth >= totalIncome * 25 && age >= 60) {
        return { retirementAge: age, netWorth: Math.round(netWorth), canRetire: true };
      }
      age++;
    }
    
    return { retirementAge: 85, netWorth: Math.round(netWorth), canRetire: false };
  };

  // Calculate Financial Health Score
  const calculateFinancialHealthScore = () => {
    const emergencyFundScore = Math.min((financialProfile.emergencyFund / (financialProfile.monthlyExpenses * 6)) * 25, 25);
    const savingsScore = Math.min((financialProfile.investments + financialProfile.retirement401k) / financialProfile.currentIncome * 50, 25);
    const debtScore = Math.max(25 - (Object.values(financialProfile.debt).reduce((sum, debt) => sum + debt, 0) / financialProfile.currentIncome * 25), 0);
    const budgetScore = Math.max(25 - Math.abs(financialProfile.currentIncome/12 - financialProfile.monthlyExpenses) / 1000, 0);
    
    return Math.round(emergencyFundScore + savingsScore + debtScore + budgetScore);
  };

  // Calculate retirement plan
  const retirementPlan = calculateRetirement();
  const healthScore = calculateFinancialHealthScore();

  // Financial Wellness Rings component
  const renderWellnessRings = () => {
    const rings = [
      {
        id: 'safety',
        title: 'Safety',
        subtitle: 'Can I survive if things go wrong?',
        description: 'Financial security baseline - emergency fund, insurance, debt management',
        icon: '🛟',
        progress: wellnessRings.safety.progress,
        color: wellnessRings.safety.color
      },
      {
        id: 'freedom', 
        title: 'Freedom',
        subtitle: 'Am I building the life I want?',
        description: 'Progress toward independence - investing, income growth, wealth building',
        icon: '🚀',
        progress: wellnessRings.freedom.progress,
        color: wellnessRings.freedom.color
      },
      {
        id: 'fulfillment',
        title: 'Fulfillment', 
        subtitle: 'Does my money align with my values?',
        description: 'Emotional alignment - conscious spending, joy, gratitude, purpose',
        icon: '💖',
        progress: wellnessRings.fulfillment.progress,
        color: wellnessRings.fulfillment.color
      }
    ];

    return (
      <div className="bg-gray-900/50 backdrop-blur-sm rounded-3xl p-6 border border-gray-700 mb-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h2 className="text-2xl font-bold text-white">Your Financial Wellness</h2>
            <p className="text-gray-400">Daily rings to track your financial health</p>
          </div>
          <button
            onClick={() => setShowReflectionPrompt(true)}
            className="bg-gradient-to-r from-teal-500 to-purple-500 text-white px-4 py-2 rounded-xl font-medium hover:shadow-lg transition-all"
          >
            Daily Check-in 💭
          </button>
        </div>

        <div className="grid grid-cols-3 gap-8">
          {rings.map((ring) => (
            <div key={ring.id} className="text-center">
              <div className="relative w-32 h-32 mx-auto mb-4">
                {/* Ring background */}
                <div className="absolute inset-0 rounded-full border-8 border-gray-700"></div>
                
                {/* Progress ring */}
                <svg className="absolute inset-0 w-32 h-32 transform -rotate-90">
                  <defs>
                    <linearGradient id={`gradient-${ring.id}`} x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor={ring.id === 'safety' ? '#60a5fa' : ring.id === 'freedom' ? '#34d399' : '#a78bfa'} />
                      <stop offset="100%" stopColor={ring.id === 'safety' ? '#06b6d4' : ring.id === 'freedom' ? '#10b981' : '#ec4899'} />
                    </linearGradient>
                  </defs>
                  <circle
                    cx="64"
                    cy="64"
                    r="56"
                    stroke={`url(#gradient-${ring.id})`}
                    strokeWidth="8"
                    fill="none"
                    strokeLinecap="round"
                    strokeDasharray={`${(ring.progress / 100) * 351.86} 351.86`}
                    className="transition-all duration-1000 ease-out"
                  />
                </svg>
                
                {/* Center content */}
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-3xl mb-1">{ring.icon}</span>
                  <span className="text-2xl font-bold text-white">{ring.progress}%</span>
                </div>
              </div>
              
              <h3 className="text-lg font-bold text-white mb-1">{ring.title}</h3>
              <p className="text-sm text-gray-400 mb-2">{ring.subtitle}</p>
              
              <button
                onClick={() => setShowRingsDetail(ring.id)}
                className="text-xs text-cyan-400 hover:text-cyan-300 transition-colors"
              >
                Learn more →
              </button>
            </div>
          ))}
        </div>

        {/* Daily Reflection Prompt Modal */}
        {showReflectionPrompt && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-gray-800 rounded-3xl p-8 max-w-md w-full border border-gray-700">
              <h3 className="text-2xl font-bold text-white mb-4">Daily Financial Reflection 💭</h3>
              <p className="text-gray-300 mb-6">How did you feel about your money choices today?</p>
              
              <div className="space-y-4 mb-6">
                <div className="bg-gray-700/50 rounded-xl p-4">
                  <div className="text-purple-400 font-medium mb-2">💸 Today's Spending</div>
                  <div className="text-sm text-gray-300">Did your purchases align with what matters to you?</div>
                </div>
                
                <div className="bg-gray-700/50 rounded-xl p-4">
                  <div className="text-green-400 font-medium mb-2">📈 Progress Made</div>
                  <div className="text-sm text-gray-300">What step did you take toward your financial goals?</div>
                </div>
                
                <div className="bg-gray-700/50 rounded-xl p-4">
                  <div className="text-blue-400 font-medium mb-2">🔮 Tomorrow's Focus</div>
                  <div className="text-sm text-gray-300">What's one thing you'll do differently tomorrow?</div>
                </div>
              </div>

              <textarea
                value={dailyReflection}
                onChange={(e) => setDailyReflection(e.target.value)}
                placeholder="Share your thoughts..."
                className="w-full p-4 bg-gray-700 rounded-xl text-white placeholder-gray-400 resize-none h-24 mb-4"
              />
              
              <div className="flex gap-3">
                <button
                  onClick={() => setShowReflectionPrompt(false)}
                  className="flex-1 bg-gray-600 text-white px-4 py-3 rounded-xl font-medium hover:bg-gray-500 transition-all"
                >
                  Skip Today
                </button>
                <button
                  onClick={() => {
                    // Update rings based on reflection (simplified)
                    setWellnessRings(prev => ({
                      ...prev,
                      fulfillment: { ...prev.fulfillment, progress: Math.min(100, prev.fulfillment.progress + 5) }
                    }));
                    setShowReflectionPrompt(false);
                    setDailyReflection('');
                  }}
                  className="flex-1 bg-gradient-to-r from-teal-500 to-purple-500 text-white px-4 py-3 rounded-xl font-medium hover:shadow-lg transition-all"
                >
                  Complete Check-in ✨
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  };

  // Navigation component
  const renderNavigation = () => (
    <nav className="bg-black/80 backdrop-blur-md border-b border-purple-900/30 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex justify-between items-center h-16">
          <button
            onClick={() => setCurrentPage('landing')}
            className="flex items-center gap-3"
          >
            <div className="text-2xl font-bold bg-gradient-to-r from-teal-400 to-purple-400 bg-clip-text text-transparent">
              🧠💰 FinThera
            </div>
            <div className="hidden sm:block text-gray-400 text-sm">
              Feel Better About Your Financial Lifestyle
            </div>
          </button>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-1">
            {[
              { id: 'landing', label: 'Home', icon: '🏠', available: true },
              { id: 'conversation', label: 'Voice Chat', icon: '🎙️', available: true },
              { id: 'profile', label: 'Profile', icon: '👤', available: userJourney.hasCompletedConversation },
              { id: 'planning', label: 'Life Plan', icon: '🎯', available: userJourney.hasSetupProfile },
              { id: 'health-score', label: 'Health Score', icon: '💎', available: userJourney.hasSetupProfile },
              { id: 'tools', label: 'Tools', icon: '🧮', available: userJourney.hasSetupProfile },
              { id: 'learn', label: 'Learn', icon: '📚', available: true },
              { id: 'optimization', label: 'Optimize', icon: '🚀', available: userJourney.hasCompletedPlanning }
            ].map(({ id, label, icon, available }) => (
              <button
                key={id}
                onClick={() => available && setCurrentPage(id)}
                disabled={!available}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  currentPage === id
                    ? 'bg-gradient-to-r from-teal-500 to-purple-600 text-white shadow-lg'
                    : available 
                      ? 'text-gray-300 hover:text-white hover:bg-gray-800'
                      : 'text-gray-600 cursor-not-allowed'
                }`}
              >
                {icon} {label}
              </button>
            ))}
          </div>
          
          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="text-gray-300 hover:text-white"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
        
        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-gray-800 border-t border-gray-700 py-4">
            <div className="flex flex-col space-y-2">
              {[
                { id: 'landing', label: 'Home', icon: '🏠', available: true },
                { id: 'conversation', label: 'Voice Chat', icon: '🎙️', available: true },
                { id: 'profile', label: 'Profile', icon: '👤', available: userJourney.hasCompletedConversation },
                { id: 'planning', label: 'Life Plan', icon: '🎯', available: userJourney.hasSetupProfile },
                { id: 'health-score', label: 'Health Score', icon: '💎', available: userJourney.hasSetupProfile },
                { id: 'tools', label: 'Tools', icon: '🧮', available: userJourney.hasSetupProfile },
                { id: 'learn', label: 'Learn', icon: '📚', available: true },
                { id: 'optimization', label: 'Optimize', icon: '🚀', available: userJourney.hasCompletedPlanning }
              ].map(({ id, label, icon, available }) => (
                <button
                  key={id}
                  onClick={() => {
                    if (available) {
                      setCurrentPage(id);
                      setMobileMenuOpen(false);
                    }
                  }}
                  disabled={!available}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all text-left ${
                    currentPage === id
                      ? 'bg-gradient-to-r from-teal-500 to-purple-600 text-white'
                      : available 
                        ? 'text-gray-300 hover:text-white hover:bg-gray-700'
                        : 'text-gray-600 cursor-not-allowed'
                  }`}
                >
                  {icon} {label}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </nav>
  );

  // Landing Page
  const renderLandingPage = () => (
    <div className="min-h-screen bg-gradient-to-br from-black via-purple-900/30 to-black text-white relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0">
        {[...Array(30)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-white rounded-full animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`
            }}
          />
        ))}
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-6 py-20 text-center">
        {/* Hero */}
        <div className="mb-16">
          <div className="inline-flex items-center px-6 py-3 rounded-full bg-white/10 backdrop-blur-md border border-white/20 mb-8">
            <span className="text-2xl mr-3">🧠</span>
            <span className="text-lg font-medium">Your Personal Financial Therapist</span>
          </div>
          
          <h1 className="text-6xl md:text-8xl font-black mb-8">
            <span className="block bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              Feel better about
            </span>
            <span className="block text-white">
              your money
            </span>
          </h1>
          
          <p className="text-2xl text-gray-300 mb-8 max-w-3xl mx-auto">
            I'm your AI financial therapist. In a <span className="text-cyan-400 font-semibold">5-minute voice conversation</span>, 
            I'll help you understand how your lifestyle choices impact your financial future.
          </p>

          <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 max-w-2xl mx-auto mb-12 border border-white/10">
            <p className="text-lg text-gray-300">
              <span className="text-purple-400 font-semibold">🎙️ Talk naturally.</span><br/>
              <span className="text-cyan-400 font-semibold">💬 I'll talk back.</span><br/>
              Understanding your relationship with money through conversation.
            </p>
          </div>

          <button
            onClick={() => setCurrentPage('conversation')}
            className="group relative px-12 py-6 bg-gradient-to-r from-purple-600 via-pink-600 to-cyan-500 rounded-2xl font-bold text-2xl hover:shadow-2xl hover:shadow-purple-500/40 transform hover:scale-105 transition-all duration-300 overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-purple-600 via-pink-600 to-cyan-500 opacity-0 group-hover:opacity-100 blur-xl transition-opacity duration-300"></div>
            <span className="relative z-10 flex items-center gap-3">
              <span>Start Voice Conversation</span>
              <MessageCircle className="w-8 h-8" />
            </span>
          </button>
        </div>

        {/* What to Expect */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            {
              icon: "🎙️",
              title: "Voice Conversation",
              desc: "Talk naturally - I'll listen and respond with my voice too"
            },
            {
              icon: "💡", 
              title: "Eye-Opening Insights",
              desc: "See the real financial impact of your daily choices"
            },
            {
              icon: "🎯",
              title: "Your Money Story",
              desc: "Understand your relationship with money - no judgment"
            }
          ].map((item, i) => (
            <div key={i} className="group bg-gradient-to-br from-gray-800/50 to-purple-900/30 backdrop-blur-sm rounded-2xl p-6 border border-gray-700 hover:scale-105 transition-all duration-300">
              <div className="text-4xl mb-4">{item.icon}</div>
              <h3 className="text-xl font-bold text-white mb-3">{item.title}</h3>
              <p className="text-gray-300">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  // Voice Conversation Page
  const renderConversationPage = () => (
    <div className="min-h-screen bg-gradient-to-br from-black via-purple-900/30 to-black">
      {showConversationResults ? renderConversationResults() : (
        <div className="max-w-4xl mx-auto p-6">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-white mb-2">
              💬 Financial Therapy Session
            </h1>
            <p className="text-gray-300 mb-4">
              A safe space to explore your relationship with money
            </p>
            
            <div className="flex justify-center gap-4 flex-wrap">
              {speechRecognition && speechSynthesis && (
                <div className="inline-flex items-center px-3 py-1 rounded-full bg-green-500/20 border border-green-500/30 text-green-300 text-sm">
                  <Mic className="w-4 h-4 mr-2" />
                  Voice conversation ready
                </div>
              )}
              
              <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm border ${
                voiceProvider === 'openai' && apiKey
                  ? 'bg-green-500/20 border-green-500/30 text-green-300 animate-pulse'
                  : voiceProvider === 'openai'
                  ? 'bg-yellow-500/20 border-yellow-500/30 text-yellow-300'
                  : voiceProvider === 'elevenlabs'
                  ? 'bg-purple-500/20 border-purple-500/30 text-purple-300'
                  : 'bg-gray-500/20 border-gray-500/30 text-gray-300'
              }`}>
                <Volume2 className="w-4 h-4 mr-2" />
                {voiceProvider === 'openai' && apiKey ? '✅ OpenAI HD Voice Active' : 
                 voiceProvider === 'openai' ? '⚠️ OpenAI Voice (Need API Key)' :
                 voiceProvider === 'elevenlabs' ? '✨ ElevenLabs Voice' : 
                 '🖥️ Browser Voice (Fallback)'}
              </div>

              {/* Voice Provider Selector */}
              <div className="inline-flex items-center gap-2">
                <select
                  value={voiceProvider}
                  onChange={(e) => switchVoiceProvider(e.target.value)}
                  className="bg-gray-700 text-white text-xs rounded px-2 py-1 border border-gray-600"
                >
                  <option value="browser">Browser Voice</option>
                  <option value="openai">OpenAI TTS</option>
                  <option value="elevenlabs">ElevenLabs (Future)</option>
                </select>
                
                {voiceProvider === 'openai' && !apiKey && (
                  <button
                    onClick={configureOpenAI}
                    className="text-xs bg-blue-500 hover:bg-blue-600 text-white px-2 py-1 rounded"
                  >
                    Setup API
                  </button>
                )}

                {/* OpenAI Voice Selector */}
                {voiceProvider === 'openai' && apiKey && (
                  <select
                    value={selectedVoice}
                    onChange={(e) => changeVoice(e.target.value)}
                    className="bg-gray-700 text-white text-xs rounded px-2 py-1 border border-gray-600"
                    title="Choose your preferred OpenAI voice"
                  >
                    <option value="nova">🌟 Nova (Warm)</option>
                    <option value="alloy">⚖️ Alloy (Balanced)</option>
                    <option value="echo">📢 Echo (Clear)</option>
                    <option value="fable">😊 Fable (Friendly)</option>
                    <option value="onyx">🗣️ Onyx (Deep)</option>
                    <option value="shimmer">✨ Shimmer (Bright)</option>
                  </select>
                )}
              </div>
            </div>
          </div>

          {/* Chat Interface */}
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-3xl border border-gray-700 h-[600px] flex flex-col">
            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {chatMessages.map((msg, index) => (
                <div key={index} className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-xs lg:max-w-md px-4 py-3 rounded-2xl ${
                    msg.type === 'user' 
                      ? 'bg-gradient-to-r from-teal-500 to-purple-500 text-white'
                      : 'bg-gray-700/70 text-gray-100'
                  }`}>
                    {msg.type === 'therapist' && (
                      <div className="flex items-center gap-2 mb-2">
                        <span className="text-lg">🧠</span>
                        <span className="text-xs text-gray-300 font-medium">Your Financial Therapist</span>
                        {isAISpeaking && index === chatMessages.length - 1 && (
                          <div className="flex items-center gap-1">
                            <div className="w-1 h-3 bg-green-400 rounded animate-pulse"></div>
                            <div className="w-1 h-4 bg-green-400 rounded animate-pulse" style={{animationDelay: '0.2s'}}></div>
                            <div className="w-1 h-3 bg-green-400 rounded animate-pulse" style={{animationDelay: '0.4s'}}></div>
                          </div>
                        )}
                      </div>
                    )}
                    <p className="text-sm leading-relaxed">{msg.message}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Input */}
            <div className="p-6 border-t border-gray-600">
              {/* Voice controls */}
              <div className="flex justify-between items-center mb-4">
                <div className="flex items-center gap-3">
                  <button
                    onClick={toggleVoice}
                    className={`p-2 rounded-lg transition-all ${
                      voiceEnabled 
                        ? 'bg-green-500/20 text-green-400 hover:bg-green-500/30' 
                        : 'bg-gray-600/50 text-gray-400 hover:bg-gray-600/70'
                    }`}
                    title={voiceEnabled ? 'Voice enabled' : 'Voice disabled'}
                  >
                    {voiceEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                  </button>
                  
                  {voiceEnabled && (
                    <span className="text-xs text-gray-400">
                      {isAISpeaking ? '🎙️ AI speaking...' : 'Voice enabled'}
                    </span>
                  )}
                </div>
              </div>
              
              <div className="flex gap-3">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && !isRecording && sendMessage()}
                  placeholder={isRecording ? "🎤 Listening... speak now" : speechRecognition ? "Type or click mic to speak..." : "Type your response..."}
                  className={`flex-1 bg-gray-700 text-white rounded-xl px-4 py-3 border transition-all focus:outline-none ${
                    isRecording 
                      ? 'border-red-500 bg-red-900/20' 
                      : 'border-gray-600 focus:border-purple-500'
                  }`}
                  disabled={isRecording}
                />
                
                {/* Voice input button */}
                {speechRecognition && (
                  <button
                    onClick={isRecording ? stopRecording : startRecording}
                    className={`p-3 rounded-xl transition-all flex items-center justify-center min-w-[48px] ${
                      isRecording 
                        ? 'bg-red-500 text-white animate-pulse shadow-lg shadow-red-500/50' 
                        : 'bg-blue-500 hover:bg-blue-600 text-white hover:shadow-lg'
                    }`}
                    title={isRecording ? 'Click to stop recording' : 'Click to start voice input'}
                  >
                    {isRecording ? (
                      <div className="flex items-center gap-1">
                        <div className="w-2 h-2 bg-white rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-white rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                        <div className="w-2 h-2 bg-white rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                      </div>
                    ) : (
                      <Mic className="w-5 h-5" />
                    )}
                  </button>
                )}
                
                <button
                  onClick={sendMessage}
                  disabled={!chatInput.trim() || isRecording}
                  className="bg-gradient-to-r from-teal-500 to-purple-500 text-white p-3 rounded-xl hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed min-w-[48px]"
                  title="Send message"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  // Conversation Results Page
  const renderConversationResults = () => {
    const impact = calculateFinancialImpact();
    
    return (
      <div className="max-w-4xl mx-auto p-6 text-white">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-cyan-400 to-pink-400 bg-clip-text text-transparent">
            ✨ Your Financial Therapy Results
          </h1>
          <p className="text-xl text-gray-300">
            Here's what your lifestyle choices reveal about your financial future
          </p>
        </div>

        {/* Key Insights */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {/* Joy vs Waste Analysis */}
          <div className="bg-gradient-to-br from-green-900/50 to-emerald-900/40 backdrop-blur-sm rounded-3xl p-8 border border-green-700/30">
            <div className="flex items-center gap-3 mb-6">
              <Heart className="w-8 h-8 text-green-400" />
              <h3 className="text-2xl font-bold text-white">Your Joy Analysis</h3>
            </div>
            
            <div className="space-y-4">
              <div className="bg-green-800/30 rounded-xl p-4">
                <div className="text-green-300 font-medium mb-2">💕 What Makes You Happy:</div>
                <div className="text-white italic">"{conversationResponses.intro || 'Not specified'}"</div>
              </div>
              
              <div className="bg-red-800/30 rounded-xl p-4">
                <div className="text-red-300 font-medium mb-2">😅 What You Regret:</div>
                <div className="text-white italic">"{conversationResponses.guilt_spending || 'Not specified'}"</div>
              </div>

              <div className="bg-blue-800/30 rounded-xl p-4">
                <div className="text-blue-300 font-medium mb-2">🌟 Your Ideal Day:</div>
                <div className="text-white italic text-sm">"{conversationResponses.ideal_day || 'Not specified'}"</div>
              </div>
            </div>
          </div>

          {/* Financial Impact */}
          <div className="bg-gradient-to-br from-purple-900/50 to-pink-900/40 backdrop-blur-sm rounded-3xl p-8 border border-purple-700/30">
            <div className="flex items-center gap-3 mb-6">
              <Calculator className="w-8 h-8 text-purple-400" />
              <h3 className="text-2xl font-bold text-white">The Money Story</h3>
            </div>
            
            <div className="space-y-4">
              <div className="text-center">
                <div className="text-4xl font-bold text-purple-400 mb-2">
                  ${impact.monthlyWaste}
                </div>
                <div className="text-gray-300 text-sm">Monthly "waste" spending</div>
              </div>

              <div className="text-center">
                <div className="text-3xl font-bold text-pink-400 mb-2">
                  ${impact.yearlyWaste.toLocaleString()}
                </div>
                <div className="text-gray-300 text-sm">Yearly opportunity cost</div>
              </div>

              <div className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl p-4 text-center">
                <div className="text-2xl font-bold text-white mb-1">
                  ${impact.tenYearInvested.toLocaleString()}
                </div>
                <div className="text-purple-100 text-sm">
                  If you invested that "waste" money for 10 years
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Goal Connection */}
        <div className="bg-gradient-to-r from-cyan-900/50 to-blue-900/40 backdrop-blur-sm rounded-3xl p-8 border border-cyan-700/30 mb-12">
          <div className="text-center">
            <h3 className="text-2xl font-bold text-white mb-4">🎯 Your Path to Your Goal</h3>
            <div className="bg-cyan-800/30 rounded-xl p-6 mb-6">
              <div className="text-cyan-300 font-medium mb-2">Your Goal:</div>
              <div className="text-white text-lg italic">"{conversationResponses.big_goal || 'Not specified'}"</div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-gray-800/50 rounded-xl p-4">
                <div className="text-2xl font-bold text-cyan-400">${impact.yearlyWaste.toLocaleString()}</div>
                <div className="text-sm text-gray-300">Available yearly by redirecting waste spending</div>
              </div>
              <div className="bg-gray-800/50 rounded-xl p-4">
                <div className="text-2xl font-bold text-green-400">${(parseInt(conversationResponses.happiness_budget) || 0) * 12}</div>
                <div className="text-sm text-gray-300">You already spend this on joy</div>
              </div>
              <div className="bg-gray-800/50 rounded-xl p-4">
                <div className="text-2xl font-bold text-purple-400">${(impact.yearlyWaste + ((parseInt(conversationResponses.happiness_budget) || 0) * 12)).toLocaleString()}</div>
                <div className="text-sm text-gray-300">Total yearly for goals + joy</div>
              </div>
            </div>
          </div>
        </div>

        {/* Life Values Report */}
        {personalizedInsights.length > 0 && (
          <div className="mb-12">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-white mb-4 bg-gradient-to-r from-teal-400 to-purple-400 bg-clip-text text-transparent">
                🧠 Your Life Values Report
              </h2>
              <p className="text-gray-300">Deep insights into your financial personality and patterns</p>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {personalizedInsights.map((insight, index) => (
                <div 
                  key={index} 
                  className="bg-gradient-to-br from-gray-800/60 to-gray-900/60 backdrop-blur-sm rounded-3xl p-8 border border-gray-600/30"
                >
                  <div className="mb-6">
                    <div className="text-sm text-teal-400 font-medium mb-2">{insight.category}</div>
                    <h3 className="text-2xl font-bold text-white mb-4">{insight.title}</h3>
                    <p className="text-gray-300 leading-relaxed mb-4">{insight.description}</p>
                    
                    {insight.deepInsight && (
                      <div className="bg-purple-900/30 rounded-xl p-4 mb-4 border border-purple-700/30">
                        <div className="text-purple-300 font-medium mb-2 text-sm">💭 Deep Insight:</div>
                        <p className="text-gray-200 text-sm">{insight.deepInsight}</p>
                      </div>
                    )}
                  </div>
                  
                  {insight.actionItems && insight.actionItems.length > 0 && (
                    <div>
                      <div className="text-white font-medium mb-3 flex items-center gap-2">
                        <Target className="w-4 h-4" />
                        Action Steps:
                      </div>
                      <div className="space-y-2">
                        {insight.actionItems.map((action, actionIndex) => (
                          <div 
                            key={actionIndex}
                            className="flex items-start gap-3 text-sm text-gray-300 bg-gray-700/30 rounded-lg p-3"
                          >
                            <div className="text-teal-400 mt-0.5">•</div>
                            <div>{action}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Key Realization */}
        <div className="bg-gradient-to-r from-yellow-900/50 to-orange-900/40 backdrop-blur-sm rounded-3xl p-8 border border-yellow-700/30 mb-12 text-center">
          <div className="text-4xl mb-4">💡</div>
          <h3 className="text-2xl font-bold text-white mb-4">Your Key Realization</h3>
          <p className="text-lg text-gray-300 leading-relaxed">
            You're not broke. You're not behind. You just need to <span className="text-yellow-400 font-semibold">redirect money you're already spending</span> from 
            things that don't bring joy to things that build your future. The money is there - it's just going to the wrong places.
          </p>
        </div>

        {/* Next Steps */}
        <div className="bg-gray-800/50 backdrop-blur-sm rounded-3xl p-8 border border-gray-700 text-center">
          <h3 className="text-2xl font-bold text-white mb-6">🚀 Your Next Steps</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 rounded-xl p-6 border border-green-500/30">
              <div className="text-3xl mb-3">📝</div>
              <h4 className="font-bold text-green-400 mb-2">Track for 1 Week</h4>
              <p className="text-sm text-gray-300">Notice what brings joy vs what you regret</p>
            </div>
            
            <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 rounded-xl p-6 border border-blue-500/30">
              <div className="text-3xl mb-3">✂️</div>
              <h4 className="font-bold text-blue-400 mb-2">Cut One Thing</h4>
              <p className="text-sm text-gray-300">Cancel one subscription or habit that doesn't spark joy</p>
            </div>
            
            <div className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-xl p-6 border border-purple-500/30">
              <div className="text-3xl mb-3">🎯</div>
              <h4 className="font-bold text-purple-400 mb-2">Redirect</h4>
              <p className="text-sm text-gray-300">Put that money toward your goal automatically</p>
            </div>
          </div>

          <div className="flex gap-4 justify-center">
            <button
              onClick={() => setCurrentPage('profile')}
              className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:shadow-lg transform hover:scale-105 transition-all"
            >
              Set Up Your Profile 👤
            </button>
            <button
              onClick={() => {
                setCurrentPage('landing');
                setChatMessages([]);
                setConversationResponses({});
                setCurrentConversationStep('intro');
                setShowConversationResults(false);
              }}
              className="bg-gradient-to-r from-teal-500 to-purple-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:shadow-lg transform hover:scale-105 transition-all"
            >
              Start Fresh Session 💫
            </button>
          </div>
        </div>
      </div>
    );
  };

  // Enhanced Profile Setup Page
  const renderProfilePage = () => (
    <div className="min-h-screen bg-gradient-to-br from-black via-purple-900/30 to-black text-white p-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-3 bg-gradient-to-r from-teal-400 to-purple-400 bg-clip-text text-transparent">
            👤 Your Financial Profile
          </h1>
          <p className="text-xl text-gray-300">
            Now let's understand your current financial situation
          </p>
        </div>
        
        {/* Wellness Rings */}
        {renderWellnessRings()}
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Personal & Income */}
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-6 border border-gray-700">
            <h3 className="text-2xl font-bold mb-6 text-white flex items-center gap-2">
              <span className="text-2xl">🧑‍💼</span>
              Personal & Income
            </h3>
            
            <div className="space-y-6">
              <div>
                <label className="block font-medium mb-2 text-gray-300">🎂 Age</label>
                <input
                  type="range"
                  min="18"
                  max="70"
                  value={financialProfile.age}
                  onChange={(e) => setFinancialProfile(prev => ({ ...prev, age: parseInt(e.target.value) }))}
                  className="w-full accent-teal-500"
                />
                <div className="text-center text-teal-400 font-semibold text-lg mt-2">
                  {financialProfile.age} years old
                </div>
              </div>

              <div>
                <label className="block font-medium mb-2 text-gray-300">💰 Your Annual Income</label>
                <input
                  type="range"
                  min="25000"
                  max="200000"
                  step="5000"
                  value={financialProfile.currentIncome}
                  onChange={(e) => setFinancialProfile(prev => ({ ...prev, currentIncome: parseInt(e.target.value) }))}
                  className="w-full accent-teal-500"
                />
                <div className="text-center text-green-400 font-semibold text-lg mt-2">
                  ${financialProfile.currentIncome.toLocaleString()}
                </div>
              </div>

              <div>
                <label className="block font-medium mb-2 text-gray-300">💸 Monthly Expenses</label>
                <input
                  type="range"
                  min="1000"
                  max="15000"
                  step="100"
                  value={financialProfile.monthlyExpenses}
                  onChange={(e) => setFinancialProfile(prev => ({ ...prev, monthlyExpenses: parseInt(e.target.value) }))}
                  className="w-full accent-teal-500"
                />
                <div className="text-center text-orange-400 font-semibold text-lg mt-2">
                  ${financialProfile.monthlyExpenses.toLocaleString()}/month
                </div>
              </div>

              <div>
                <label className="block font-medium mb-2 text-gray-300">🎯 Risk Tolerance</label>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { value: 'conservative', label: '🛡️ Conservative', desc: 'Safety first' },
                    { value: 'balanced', label: '⚖️ Balanced', desc: 'Moderate risk' },
                    { value: 'aggressive', label: '🚀 Aggressive', desc: 'High growth' }
                  ].map(option => (
                    <button
                      key={option.value}
                      onClick={() => setFinancialProfile(prev => ({ ...prev, riskTolerance: option.value }))}
                      className={`p-3 rounded-xl text-center transition-all ${
                        financialProfile.riskTolerance === option.value
                          ? 'bg-gradient-to-br from-teal-500 to-purple-600 text-white shadow-lg'
                          : 'bg-gray-700/50 text-gray-300 hover:bg-gray-600/50'
                      }`}
                    >
                      <div className="font-medium text-sm">{option.label}</div>
                      <div className="text-xs opacity-80">{option.desc}</div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Assets & Savings */}
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-6 border border-gray-700">
            <h3 className="text-2xl font-bold mb-6 text-white flex items-center gap-2">
              <span className="text-2xl">💎</span>
              Assets & Savings
            </h3>
            
            <div className="space-y-6">
              <div>
                <label className="block font-medium mb-2 text-gray-300">🏦 Emergency Fund</label>
                <input
                  type="range"
                  min="0"
                  max="50000"
                  step="500"
                  value={financialProfile.emergencyFund}
                  onChange={(e) => setFinancialProfile(prev => ({ ...prev, emergencyFund: parseInt(e.target.value) }))}
                  className="w-full accent-teal-500"
                />
                <div className="text-center text-teal-400 font-semibold text-lg mt-2">
                  ${financialProfile.emergencyFund.toLocaleString()}
                </div>
              </div>

              <div>
                <label className="block font-medium mb-2 text-gray-300">📈 Total Investments</label>
                <input
                  type="range"
                  min="0"
                  max="100000"
                  step="1000"
                  value={financialProfile.investments}
                  onChange={(e) => setFinancialProfile(prev => ({ ...prev, investments: parseInt(e.target.value) }))}
                  className="w-full accent-teal-500"
                />
                <div className="text-center text-green-400 font-semibold text-lg mt-2">
                  ${financialProfile.investments.toLocaleString()}
                </div>
              </div>

              <div>
                <label className="block font-medium mb-2 text-gray-300">🏢 401k Balance</label>
                <input
                  type="range"
                  min="0"
                  max="75000"
                  step="1000"
                  value={financialProfile.retirement401k}
                  onChange={(e) => setFinancialProfile(prev => ({ ...prev, retirement401k: parseInt(e.target.value) }))}
                  className="w-full accent-teal-500"
                />
                <div className="text-center text-green-400 font-semibold text-lg mt-2">
                  ${financialProfile.retirement401k.toLocaleString()}
                </div>
              </div>

              <div>
                <label className="block font-medium mb-2 text-gray-300">🎯 Financial Goals</label>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { key: 'buyHome', label: '🏠 Buy Home', active: financialProfile.financialGoals.buyHome },
                    { key: 'travel', label: '✈️ Travel', active: financialProfile.financialGoals.travel },
                    { key: 'earlyRetirement', label: '🏖️ Early Retirement', active: financialProfile.financialGoals.earlyRetirement },
                    { key: 'payOffDebt', label: '💳 Pay Off Debt', active: financialProfile.financialGoals.payOffDebt }
                  ].map(goal => (
                    <button
                      key={goal.key}
                      onClick={() => setFinancialProfile(prev => ({
                        ...prev,
                        financialGoals: {
                          ...prev.financialGoals,
                          [goal.key]: !prev.financialGoals[goal.key]
                        }
                      }))}
                      className={`p-3 rounded-xl text-center transition-all text-sm ${
                        goal.active
                          ? 'bg-gradient-to-br from-green-500 to-teal-600 text-white shadow-lg'
                          : 'bg-gray-700/50 text-gray-300 hover:bg-gray-600/50'
                      }`}
                    >
                      {goal.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Debt Overview */}
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-6 border border-gray-700">
            <h3 className="text-2xl font-bold mb-6 text-white flex items-center gap-2">
              <span className="text-2xl">📊</span>
              Debt Overview
            </h3>
            
            <div className="space-y-6">
              <div>
                <label className="block font-medium mb-2 text-gray-300">🎓 Student Loans</label>
                <input
                  type="number"
                  value={financialProfile.debt.student}
                  onChange={(e) => setFinancialProfile(prev => ({ 
                    ...prev, 
                    debt: { ...prev.debt, student: parseInt(e.target.value) || 0 }
                  }))}
                  className="w-full bg-gray-700 text-white rounded-lg px-4 py-2 border border-gray-600 focus:border-teal-500 focus:outline-none"
                  placeholder="25000"
                />
              </div>

              <div>
                <label className="block font-medium mb-2 text-gray-300">💳 Credit Cards</label>
                <input
                  type="number"
                  value={financialProfile.debt.credit}
                  onChange={(e) => setFinancialProfile(prev => ({ 
                    ...prev, 
                    debt: { ...prev.debt, credit: parseInt(e.target.value) || 0 }
                  }))}
                  className="w-full bg-gray-700 text-white rounded-lg px-4 py-2 border border-gray-600 focus:border-teal-500 focus:outline-none"
                  placeholder="3000"
                />
              </div>

              <div>
                <label className="block font-medium mb-2 text-gray-300">🚗 Auto Loan</label>
                <input
                  type="number"
                  value={financialProfile.debt.car}
                  onChange={(e) => setFinancialProfile(prev => ({ 
                    ...prev, 
                    debt: { ...prev.debt, car: parseInt(e.target.value) || 0 }
                  }))}
                  className="w-full bg-gray-700 text-white rounded-lg px-4 py-2 border border-gray-600 focus:border-teal-500 focus:outline-none"
                  placeholder="12000"
                />
              </div>

              <div>
                <label className="block font-medium mb-2 text-gray-300">🏠 Mortgage</label>
                <input
                  type="number"
                  value={financialProfile.debt.mortgage}
                  onChange={(e) => setFinancialProfile(prev => ({ 
                    ...prev, 
                    debt: { ...prev.debt, mortgage: parseInt(e.target.value) || 0 }
                  }))}
                  className="w-full bg-gray-700 text-white rounded-lg px-4 py-2 border border-gray-600 focus:border-teal-500 focus:outline-none"
                  placeholder="0"
                />
              </div>

              <div className="bg-red-900/30 rounded-xl p-4 text-center border border-red-700/30">
                <div className="text-red-400 font-bold text-2xl">
                  ${Object.values(financialProfile.debt).reduce((sum, debt) => sum + debt, 0).toLocaleString()}
                </div>
                <div className="text-red-300 text-sm">Total Debt</div>
              </div>
            </div>
          </div>

          {/* Life Values Integration */}
          {personalizedInsights.length > 0 && (
            <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-6 border border-gray-700">
              <h3 className="text-2xl font-bold mb-6 text-white flex items-center gap-2">
                <span className="text-2xl">🧠</span>
                Your Life Values
              </h3>
              
              <div className="space-y-4">
                <div className="bg-purple-900/30 rounded-xl p-4 border border-purple-700/30">
                  <div className="text-purple-300 font-medium mb-2">Financial Archetype:</div>
                  <div className="text-white font-semibold">{financialProfile.lifeValues.financialArchetype}</div>
                </div>
                
                <div className="bg-teal-900/30 rounded-xl p-4 border border-teal-700/30">
                  <div className="text-teal-300 font-medium mb-2">Core Motivations:</div>
                  <div className="flex flex-wrap gap-2">
                    {financialProfile.lifeValues.coreMotivations.map((motivation, index) => (
                      <span key={index} className="bg-teal-600/30 text-teal-200 px-2 py-1 rounded-lg text-sm">
                        {motivation}
                      </span>
                    ))}
                  </div>
                </div>
                
                <div className="bg-gray-700/30 rounded-xl p-4 border border-gray-600/30">
                  <div className="text-gray-300 font-medium mb-2">Personality Type:</div>
                  <div className="text-white">{financialProfile.lifeValues.personalityType}</div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Continue Button */}
        <div className="text-center mt-8">
          <button
            onClick={() => {
              setUserJourney(prev => ({ 
                ...prev, 
                hasSetupProfile: true, 
                currentStep: 'planning' 
              }));
              setCurrentPage('planning');
            }}
            className="bg-gradient-to-r from-teal-500 to-purple-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:shadow-lg transform hover:scale-105 transition-all"
          >
            Continue to Life Planning 🎯
          </button>
        </div>
      </div>
    </div>
  );

  // Life Planner Page
  const renderPlanningPage = () => {
    const currentPhaseData = phases[currentPhase];
    
    return (
      <div className="min-h-screen bg-gradient-to-br from-black via-purple-900/30 to-black text-white p-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold mb-3 bg-gradient-to-r from-teal-400 to-purple-400 bg-clip-text text-transparent">
              🎯 Life Planner
            </h1>
            <p className="text-xl text-gray-300">Design your ideal lifestyle for each decade</p>
          </div>
          
          {/* Wellness Rings */}
          {renderWellnessRings()}
          
          {/* Phase Selector */}
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-6 mb-8 border border-gray-700">
            <h3 className="text-xl font-bold mb-4">Choose Your Life Phase to Explore</h3>
            <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
              {Object.entries(phases).map(([key, phase]) => {
                const Icon = phase.icon;
                return (
                  <button
                    key={key}
                    onClick={() => setCurrentPhase(key)}
                    className={`p-4 rounded-xl transition-all ${
                      currentPhase === key
                        ? 'bg-gradient-to-br from-teal-500 to-purple-600 text-white shadow-lg scale-105'
                        : 'bg-gray-700/50 text-gray-300 hover:bg-gray-600/50'
                    }`}
                  >
                    <Icon className="w-8 h-8 mx-auto mb-2" />
                    <div className="font-bold text-sm">{phase.title}</div>
                    <div className="text-xs opacity-80">{phase.ageRange}</div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Current Phase Overview */}
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-8 mb-8 border border-gray-700">
            <div className="text-center mb-6">
              <h2 className="text-3xl font-bold text-white mb-2">{currentPhaseData.title}</h2>
              <p className="text-xl text-gray-300 mb-4">{currentPhaseData.description}</p>
              <p className="text-lg text-purple-300 italic">{currentPhaseData.vibe}</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-teal-900/30 rounded-xl p-4 border border-teal-700/30">
                <h4 className="font-bold text-teal-300 mb-3">🎯 Priorities</h4>
                <ul className="space-y-1 text-sm text-gray-300">
                  {currentPhaseData.priorities.map((priority, index) => (
                    <li key={index}>• {priority}</li>
                  ))}
                </ul>
              </div>

              <div className="bg-orange-900/30 rounded-xl p-4 border border-orange-700/30">
                <h4 className="font-bold text-orange-300 mb-3">💰 Key Expenses</h4>
                <ul className="space-y-1 text-sm text-gray-300">
                  {currentPhaseData.expenses.map((expense, index) => (
                    <li key={index}>• {expense}</li>
                  ))}
                </ul>
              </div>

              <div className="bg-green-900/30 rounded-xl p-4 border border-green-700/30">
                <h4 className="font-bold text-green-300 mb-3">📈 Investments</h4>
                <ul className="space-y-1 text-sm text-gray-300">
                  {currentPhaseData.investments.map((investment, index) => (
                    <li key={index}>• {investment}</li>
                  ))}
                </ul>
              </div>

              <div className="bg-purple-900/30 rounded-xl p-4 border border-purple-700/30">
                <h4 className="font-bold text-purple-300 mb-3">🏆 Goals</h4>
                <ul className="space-y-1 text-sm text-gray-300">
                  {currentPhaseData.goals.map((goal, index) => (
                    <li key={index}>• {goal}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Income Planning */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-6 border border-gray-700">
              <h3 className="text-2xl font-bold mb-6 text-white flex items-center gap-2">
                <span className="text-2xl">💰</span>
                Income Planning
              </h3>
              
              <div className="space-y-6">
                <div>
                  <label className="block font-medium mb-2 text-gray-300">Your Expected Income</label>
                  <input
                    type="range"
                    min="30000"
                    max="300000"
                    step="5000"
                    value={incomeByDecade[currentPhase]?.you || 60000}
                    onChange={(e) => setIncomeByDecade(prev => ({
                      ...prev,
                      [currentPhase]: { ...prev[currentPhase], you: parseInt(e.target.value) }
                    }))}
                    className="w-full accent-teal-500"
                  />
                  <div className="text-center text-green-400 font-semibold text-lg mt-2">
                    ${(incomeByDecade[currentPhase]?.you || 60000).toLocaleString()}
                  </div>
                </div>

                <div>
                  <label className="block font-medium mb-2 text-gray-300">Partner's Expected Income</label>
                  <input
                    type="range"
                    min="0"
                    max="300000"
                    step="5000"
                    value={incomeByDecade[currentPhase]?.partner || 0}
                    onChange={(e) => setIncomeByDecade(prev => ({
                      ...prev,
                      [currentPhase]: { ...prev[currentPhase], partner: parseInt(e.target.value) }
                    }))}
                    className="w-full accent-teal-500"
                  />
                  <div className="text-center text-green-400 font-semibold text-lg mt-2">
                    ${(incomeByDecade[currentPhase]?.partner || 0).toLocaleString()}
                  </div>
                </div>

                <div className="bg-green-900/30 rounded-xl p-4 text-center border border-green-700/30">
                  <div className="text-green-400 font-bold text-2xl">
                    ${((incomeByDecade[currentPhase]?.you || 60000) + (incomeByDecade[currentPhase]?.partner || 0)).toLocaleString()}
                  </div>
                  <div className="text-green-300 text-sm">Combined Annual Income</div>
                </div>
              </div>
            </div>

            {/* Lifestyle Choices */}
            <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-6 border border-gray-700">
              <h3 className="text-2xl font-bold mb-6 text-white flex items-center gap-2">
                <span className="text-2xl">🏠</span>
                Lifestyle Choices
              </h3>
              
              <div className="space-y-6">
                {Object.entries(lifestyleChoices[currentPhase] || {}).map(([category, level]) => (
                  <div key={category}>
                    <label className="block font-medium mb-2 text-gray-300 capitalize">
                      {getLifestyleCategoryIcon(category)} {category.replace('_', ' ')}
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {['low', 'medium', 'high'].map(option => (
                        <button
                          key={option}
                          onClick={() => setLifestyleChoices(prev => ({
                            ...prev,
                            [currentPhase]: { ...prev[currentPhase], [category]: option }
                          }))}
                          className={`p-2 rounded-lg text-center transition-all text-sm ${
                            level === option
                              ? 'bg-gradient-to-br from-teal-500 to-purple-600 text-white shadow-lg'
                              : 'bg-gray-700/50 text-gray-300 hover:bg-gray-600/50'
                          }`}
                        >
                          {option.charAt(0).toUpperCase() + option.slice(1)}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Savings Rate */}
            <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-6 border border-gray-700">
              <h3 className="text-2xl font-bold mb-6 text-white flex items-center gap-2">
                <span className="text-2xl">💎</span>
                Savings Rate
              </h3>
              
              <div>
                <label className="block font-medium mb-2 text-gray-300">Target Savings Rate</label>
                <input
                  type="range"
                  min="5"
                  max="50"
                  value={savingsRateByDecade[currentPhase] || 20}
                  onChange={(e) => setSavingsRateByDecade(prev => ({
                    ...prev,
                    [currentPhase]: parseInt(e.target.value)
                  }))}
                  className="w-full accent-teal-500"
                />
                <div className="text-center text-teal-400 font-semibold text-lg mt-2">
                  {savingsRateByDecade[currentPhase] || 20}%
                </div>
              </div>

              <div className="mt-6 bg-teal-900/30 rounded-xl p-4 text-center border border-teal-700/30">
                <div className="text-teal-400 font-bold text-xl">
                  ${(((incomeByDecade[currentPhase]?.you || 60000) + (incomeByDecade[currentPhase]?.partner || 0)) * (savingsRateByDecade[currentPhase] || 20) / 100).toLocaleString()}
                </div>
                <div className="text-teal-300 text-sm">Annual Savings Target</div>
              </div>
            </div>

            {/* Investment Strategy */}
            <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-6 border border-gray-700">
              <h3 className="text-2xl font-bold mb-6 text-white flex items-center gap-2">
                <span className="text-2xl">📈</span>
                Investment Strategy
              </h3>
              
              <div className="space-y-4">
                {Object.entries(strategies).map(([key, strategy]) => (
                  <button
                    key={key}
                    onClick={() => setInvestmentStrategy(key)}
                    className={`w-full p-4 rounded-xl text-left transition-all ${
                      investmentStrategy === key
                        ? 'bg-gradient-to-br from-teal-500 to-purple-600 text-white shadow-lg'
                        : 'bg-gray-700/50 text-gray-300 hover:bg-gray-600/50'
                    }`}
                  >
                    <div className="font-bold mb-1">{strategy.name}</div>
                    <div className="text-sm opacity-80 mb-2">{strategy.description}</div>
                    <div className="text-xs">
                      Stocks {strategy.allocation.stocks}% • Bonds {strategy.allocation.bonds}% • Cash {strategy.allocation.cash}%
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Retirement Projection */}
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-8 mt-8 border border-gray-700">
            <h3 className="text-2xl font-bold mb-6 text-white text-center">🚀 Your Retirement Projection</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-green-900/30 rounded-xl p-6 text-center border border-green-700/30">
                <div className="text-green-400 font-bold text-3xl mb-2">
                  {calculateRetirement().retirementAge}
                </div>
                <div className="text-green-300">Retirement Age</div>
              </div>

              <div className="bg-purple-900/30 rounded-xl p-6 text-center border border-purple-700/30">
                <div className="text-purple-400 font-bold text-3xl mb-2">
                  ${calculateRetirement().netWorth.toLocaleString()}
                </div>
                <div className="text-purple-300">Net Worth at Retirement</div>
              </div>

              <div className="bg-teal-900/30 rounded-xl p-6 text-center border border-teal-700/30">
                <div className="text-teal-400 font-bold text-3xl mb-2">
                  {calculateRetirement().canRetire ? '✅' : '⚠️'}
                </div>
                <div className="text-teal-300">{calculateRetirement().canRetire ? 'On Track' : 'Needs Adjustment'}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Helper function to get lifestyle category icons
  const getLifestyleCategoryIcon = (category) => {
    const icons = {
      housing: '🏠',
      transportation: '🚗',
      food: '🍽️',
      entertainment: '🎬',
      childcare: '👶',
      healthcare: '🏥',
      education: '🎓',
      college: '🎓',
      travel: '✈️',
      location: '📍'
    };
    return icons[category] || '💰';
  };

  // Main component render logic
  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      {/* Starry night background */}
      <div className="absolute inset-0 bg-gradient-to-b from-gray-900 via-black to-purple-900/20 pointer-events-none"></div>
      <div className="absolute inset-0 opacity-30 pointer-events-none">
        {/* Stars */}
        <div className="absolute top-10 left-10 w-1 h-1 bg-white rounded-full animate-pulse"></div>
        <div className="absolute top-20 left-32 w-0.5 h-0.5 bg-teal-200 rounded-full animate-pulse" style={{animationDelay: '1s'}}></div>
        <div className="absolute top-32 left-64 w-1 h-1 bg-purple-200 rounded-full animate-pulse" style={{animationDelay: '2s'}}></div>
        <div className="absolute top-16 right-20 w-0.5 h-0.5 bg-white rounded-full animate-pulse" style={{animationDelay: '0.5s'}}></div>
        <div className="absolute top-40 right-40 w-1 h-1 bg-teal-300 rounded-full animate-pulse" style={{animationDelay: '1.5s'}}></div>
        <div className="absolute top-24 right-64 w-0.5 h-0.5 bg-purple-300 rounded-full animate-pulse" style={{animationDelay: '2.5s'}}></div>
        <div className="absolute bottom-32 left-20 w-1 h-1 bg-white rounded-full animate-pulse" style={{animationDelay: '3s'}}></div>
        <div className="absolute bottom-48 left-48 w-0.5 h-0.5 bg-teal-200 rounded-full animate-pulse" style={{animationDelay: '0.8s'}}></div>
        <div className="absolute bottom-20 right-32 w-1 h-1 bg-purple-200 rounded-full animate-pulse" style={{animationDelay: '1.8s'}}></div>
        <div className="absolute bottom-40 right-16 w-0.5 h-0.5 bg-white rounded-full animate-pulse" style={{animationDelay: '2.8s'}}></div>
      </div>
      <div className="relative z-10">
      {renderNavigation()}
      
      {currentPage === 'landing' && renderLandingPage()}
      {currentPage === 'conversation' && renderConversationPage()}
      {currentPage === 'profile' && renderProfilePage()}
      {currentPage === 'planning' && renderPlanningPage()}
      
      {/* Other pages would be implemented here following the same pattern */}
      {(currentPage === 'health-score' || currentPage === 'tools' || currentPage === 'learn' || currentPage === 'optimization') && (
        <div className="min-h-screen bg-gradient-to-br from-black via-purple-900/30 to-black text-white flex items-center justify-center">
          <div className="text-center">
            <div className="text-6xl mb-4">🚧</div>
            <h2 className="text-3xl font-bold mb-4">Coming Soon!</h2>
            <p className="text-xl text-gray-300 mb-8">
              This section is being built. For now, enjoy the voice conversation experience!
            </p>
            <button
              onClick={() => setCurrentPage('conversation')}
              className="bg-gradient-to-r from-teal-500 to-purple-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:shadow-lg transform hover:scale-105 transition-all"
            >
              Back to Voice Chat 🎙️
            </button>
          </div>
        </div>
      )}
      </div>
    </div>
  );
};

export default FinancialTherapyPlatform;