import FinancialTherapyPlatform from './FinancialTherapyPlatform'

function App() {
  return <FinancialTherapyPlatform />
}

export default App